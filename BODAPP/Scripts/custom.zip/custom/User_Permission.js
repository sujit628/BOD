﻿var type;
var UserId;
var ModuleId;
var Role = '';
$(document).ready(function () {
    UserId = getParameterByName('UserId'); //Get Data From URL QueryString 
    ModuleId = getParameterByName('ModuleId');
    Role = getParameterByName('Mode');
})

//Get Data From URL   
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
           results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}


}
$(document).on('click', '#btnSave', function () {
    //SaveRecord();
    checked();
   
})
function checked() {
    debugger;
    var menuArr = [];

    $('input:checkbox[class=mainMenu]').each(function () {
        if (this.checked) {
            menuArr.push({ MenuId: parseInt(this.value) });
        }
    });

    $('input:checkbox[class=subMenu]').each(function () {
        if (this.checked) {
            menuArr.push({ MenuId: parseInt(this.value) });
        }
    });

}
function activateSubMenu(menu, mid) {
    if ($(menu).is(':checked')) {
        // $('submenu_' + mid).removeAttr('disabled');
        'input:checkbox[class=mainMenu]'
        $('input:checkbox[name=submenu_' + mid + ']').removeAttr('disabled');
    }
    else {
        // $('submenu_' + mid).prop('checked', false).attr('disabled', 'disabled');
        $('input:checkbox[name=submenu_' + mid + ']').prop('checked', false).attr('disabled', 'disabled');
    }
}
function SaveRecord() {

    var menuArr = [];

    $('input:checkbox[class=mainMenu]').each(function () {
        if (this.checked) {
            menuArr.push({ MenuId: parseInt(this.value) });
        }
    });

    $('input:checkbox[class=subMenu]').each(function () {
        if (this.checked) {
            menuArr.push({ MenuId: parseInt(this.value) });
        }
    });

    var _data = JSON.stringify({
        entity: {
            UserId: parseInt($("#User_ID").val()),
            UserLoginID: $.trim($("#username").val()),
            Password: $.trim($("#password").val()),
            //UserName: $.trim($("#fullname").val()),
            status: $.trim($('#status').val()),
            mainmenuList: menuArr,
            Module: parseInt(ModuleId),
        }
    });

    $.ajax({
        type: "POST",
        url: '/ScriptJson/InsertUpdateUser',
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
                AddErrorAlert("success", data.Message);
               
            }
            else {
                AddErrorAlert("Error", data.Message);
            }
        },
        error: function (data) {
            AddErrorAlert("Error", "Process Not Complete");
        }
    });
}


//function retrive(id, mode) {

//    var _data = JSON.stringify({
//        global: {
//            TransactionType: globalData.TransactionType,
//            Param: globalData.Param,
//            paramValue: parseInt(id),
//            StoreProcedure: globalData.StoreProcedure
//        }
//    });

//    $.ajax({
//        type: "POST",
//        url: "/ScriptJson/GetGlobalMaster",
//        data: _data,
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        async: false,
//        success: function (data) {

//            $('#User_Id').val(data["UserID"]);
//            $('#fullname').val(data["UserName"]).siblings('label').addClass('active');
//            $('#username').val(data["UserLoginID"]).siblings('label').addClass('active');
//            $('#password').val(data["Password"]).siblings('label').addClass('active');
//            $('#status').val(data["status"]).change();



//            if (mode == 'v') {
//                $(document).find('input, textarea, select').attr('disabled', 'disabled');
//                $('#btnSave').attr('id', 'btnEdit').html('Edit');

//                $(document).on('click', '#btnEdit', function () {
//                    $(document).find('input, textarea, select').removeAttr('disabled');
//                    $('#btnEdit').attr('id', 'btnSave').html('Submit');
//                })
//            }
//        },
//        error: function (data) {
//            swal({
//                title: 'Process not completed',
//                icon: 'error'
//            })
//        }
//    });
//    return false;

//}

$('#password, #confirm_password').on('keyup', function () {
    if ($('#password').val() == $('#confirm_password').val()) {
        $('#confirm_password').css('border-color', 'green');


    } else
        $('#confirm_password').css('border-color', 'red');

});