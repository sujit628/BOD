﻿
$(document).ready(function () {
    $('.alphabets').on('input', function () {

        let inputValue = $(this).val();

        let alphabeticValue = inputValue.replace(/[^a-zA-Z\s]/g, '');

        $(this).val(alphabeticValue);
    });
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    var today = dd + '/' + mm + '/' + yyyy;
    txtApntDate = $("#txtApntDate").val();


    if (txtApntDate == "") {
        document.getElementById("txtApntDate").value = today;
    }

    DropdownBinder.DDLData = {
        tableName: "SectorSetUp_SM",
        Text: 'SM_SectorName',
        Value: 'SM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlSector");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "EnterpriseTypeSetUp_ETM",
        Text: 'ETM_EnterpriseType',
        Value: 'ETM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlBusinessType");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "ProvinceSetUp_PM",
        Text: 'PM_Province',
        Value: 'PM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlProvince");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "LegalEntitySetUp_LEM",
        Text: 'LEM_LegalEntity',
        Value: 'LEM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlLegalEntity");
    DropdownBinder.Execute();

});

$("#btnSave").click(function () {
    SaveRecords();
});
function SaveRecords() {

    var _data = JSON.stringify({
        entity: {
            SMME_Id: $('#hdnId').val(),
            SMME_PrimaryContactName: $.trim($('#txtContactName').val()),
            SMME_PrimaryContactEmail: $('#txtContactEmail').val(),
            SMME_Password: $('#txtPassword').val(),
            SMME_SecondaryContactName: $('#SecondaryContactName').val(),
            SMME_SecondaryContactEmail: $('#SecondaryContactEmail').val(),
            SMME_PrimaryContactNo: $('#PrimaryContactNumber').val(),
            SMME_SecondaryContactNo: $('#SecondaryContactNumber').val(),

            SMME_CompanyName: $.trim($('#txtCompanyName').val()),
            SMME_RegNumber: $('#txtRegNum').val(),
            SMME_SectorId: $('#ddlSector').val(),
            SMME_SMMETypeId: $('#ddlBusinessType').val(),
            SMME_ProvinceId: $('#ddlProvince').val(),
            SMME_BusinessAddress: $('#txtBusinessAddress').val(),

            SMME_LegalEntityTypeId: $('#ddlLegalEntity').val(),
            SMME_TaxNumber: $('#txtTaxNumber').val(),
            SMME_VatNumber: $('#txtVatNumber').val(),
            SMME_IncorporationDate: $('#txtIncorporationDate').val(),
            SMME_RegNum2: $('#txtRegNum2').val(),
            
            SMME_BillingContactNumber: $('#txtBillingContactNum').val(),
            SMME_BillingAddress: $('#txtBillingAddress').val(),
            
        }
    }); $.ajax({
        type: "POST",
        url: '/ScriptJson/InsertUpdateSMMERegistration',
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
                Swal.fire({
                    title: data.Message,
                    icon: "success",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
                $(".form-control").val('')
               
                window.location = "/Account/SMMELogin";

            }
            else {
               
                Swal.fire({
                    title: data.Message,
                    icon: "error",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
            }
        },
        error: function (data) {
         
            Swal.fire({
                title: 'Process Not Complete',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
        }
    });
}
