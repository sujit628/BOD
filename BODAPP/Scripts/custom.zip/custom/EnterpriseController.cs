﻿using BODDal;
using BODDal.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace BODAPP.Controllers
{
    public class EnterpriseController : Controller
    {
        public static UserModel UserModel { get; set; }
        public static UserModel EnterpriseUserModel { get; set; }
        public GlobalData global = new GlobalData();
        public static DataTable dt = new DataTable();
        DAL dl = new DAL();

        public static void GetSession()
        {
            UserModel = (UserModel)System.Web.HttpContext.Current.Session["UserDataModel"];
            EnterpriseUserModel = (UserModel)System.Web.HttpContext.Current.Session["EnterpriseUserDataModel"];
        }

        public EnterpriseController()
        {
            GetSession();
        }
        private static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }

        private static T GetItem1<T>(DataTable dt)
        {
            Type temp = typeof(T);

            T data = Activator.CreateInstance<T>();
            foreach (DataRow row in dt.Rows)
            {
                data = GetItem<T>(row);
            }
            
            return data;
        }
        public ActionResult EnterpriseProfieView_SMME(int? Id)
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            if (Id == null)
            {
                Id = EnterpriseUserModel.UM_MainID;
            }
            DataSet ds = new DataSet();
            global.StoreProcedure = "EnterpriseRegistration_USP";
            global.TransactionType = "Select";
            global.param1 = "ENR_Id";
            global.param1Value = Id;
            ds = dl.GetGlobalMasterTransactionSingle1(global);
            EnterpriseRegistration Entreg = new EnterpriseRegistration();
            Entreg = GetItem1<EnterpriseRegistration>(ds.Tables[0]);
            Entreg.EnterPriseWiseSMMEList = ConvertDataTable<EnterpriiseWiseSMME>(ds.Tables[1]);
            var Srecord = Entreg;
            return View(Srecord);
        }
        public ActionResult EnterpriseProfieView_Branches()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            DataTable dt = new DataTable();
            ViewBag.EntrId = EnterpriseUserModel.UM_MainID;
            global.StoreProcedure = "EnterpriseRegistration_USP";
            global.TransactionType = "Select";
            global.param1 = "ENR_Id";
            global.param1Value = EnterpriseUserModel.UM_MainID;
            dt = dl.GetGlobalMasterTransaction(global);
            EnterpriseRegistration Entreg = new EnterpriseRegistration();
            Entreg = GetItem1<EnterpriseRegistration>(dt);
            var Srecord = Entreg;
            return View(Srecord);
           
        }
        public ActionResult EnterpriseProfieView_Projects()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            else
            {
                ViewBag.EntrId = EnterpriseUserModel.UM_MainID;
            }
            DataTable dt = new DataTable();
            global.StoreProcedure = "EnterpriseRegistration_USP";
            global.TransactionType = "Select";
            global.param1 = "ENR_Id";
            global.param1Value = EnterpriseUserModel.UM_MainID;
            dt = dl.GetGlobalMasterTransaction(global);
            EnterpriseRegistration Entreg = new EnterpriseRegistration();
            Entreg = GetItem1<EnterpriseRegistration>(dt);
            var Srecord = Entreg;
            return View(Srecord);
            
        }
        public ActionResult EnterpriseProfieView_Profiles()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            } 
            DataTable dt = new DataTable();
            global.StoreProcedure = "EnterpriseRegistration_USP";
            global.TransactionType = "Select";
            global.param1 = "ENR_Id";
            global.param1Value = EnterpriseUserModel.UM_MainID;
            dt = dl.GetGlobalMasterTransaction(global);
            EnterpriseRegistration Entreg = new EnterpriseRegistration();
            Entreg = GetItem1<EnterpriseRegistration>(dt);
            var Srecord = Entreg;
            return View(Srecord);
           
        }
        public ActionResult EnterpriseLists()
        {
            if (UserModel == null)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View();
        }
        public ActionResult EnterpriseDashboard()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            return View();
        }
        public ActionResult EnterpriseWiseSMME(int? Id)
        {
            if (UserModel == null)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            DataSet ds = new DataSet();
            global.param1Value = Id;
            global.param1 = "ENR_Id";
            global.StoreProcedure = "EnterpriseRegistration_USP";
            global.TransactionType = "SelectEnterpriseWiseSMME";
            ds = dl.GetGlobalMasterTransactionSingle1(global);
            EnterpriseRegistration Entreg = new EnterpriseRegistration();
            Entreg = GetItem1<EnterpriseRegistration>(ds.Tables[0]);
            Entreg.SMMERegistrationList = ConvertDataTable<SMMERegistration>(ds.Tables[1]);
            var Srecord = Entreg;
            return View(Srecord);
        }
        public ActionResult EnterpriseWiseSMMEList()
        {
            if (UserModel == null)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
          
            return View();
        }
        public ActionResult ViewAllSMMEForEnterprise()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            return View();
        }
        public ActionResult AssignSMMEToEnterprise()
        {
            if (UserModel == null)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View();
        }
        public ActionResult ViewAllEnterPriseUser()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            return View();
        }
        public ActionResult AddEnterPriseUser()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            return View();
        }
        public ActionResult ViewAllUser()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            return View();
        }
        public ActionResult EnterpriseProfieView_SMMESingle(int? Id)
        {
            if (UserModel == null)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            if (Id == null)
            {
                Id = UserModel.UM_MainID;
            }
            DataTable dt = new DataTable();
            global.StoreProcedure = "EnterpriseWiseSMME_USP";
            global.TransactionType = "SelectSMMEByEnterprise";
            global.param1 = "EWS_EnterpriseId";
            global.param1Value = Id;
            dt = dl.GetGlobalMasterTransaction(global);
            EnterpriiseWiseSMME Entreg = new EnterpriiseWiseSMME();
            Entreg = GetItem1<EnterpriiseWiseSMME>(dt);
            Entreg.EnterpriiseWiseSMMEList = ConvertDataTable<EnterpriiseWiseSMME>(dt);
            var Srecord = Entreg;
            return View(Srecord);
        }

        public ActionResult AddBranch()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            ViewBag.EntrId = EnterpriseUserModel.UM_MainID;
            return View();
        }
        public ActionResult ViewAllBranch()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }
            ViewBag.EntrId = EnterpriseUserModel.UM_MainID;
            return View();
        }

        public ActionResult EnterpriseProfileComplete()
        {
            if (EnterpriseUserModel == null)
            {
                return RedirectToAction("EnterpriseLogin", "Account");
            }

            ViewBag.EntrId = EnterpriseUserModel.UM_MainID;
            DataSet ds = new DataSet();
            global.param1Value = EnterpriseUserModel.UM_MainID;
            global.param1 = "ENR_Id";
            global.StoreProcedure = "EnterpriseRegistration_USP";
            global.TransactionType = "SelectEnterpriseWiseSMME";
            ds = dl.GetGlobalMasterTransactionSingle1(global);
            EnterpriseRegistration Entreg = new EnterpriseRegistration();
            Entreg = GetItem1<EnterpriseRegistration>(ds.Tables[0]);
          
            var Srecord = Entreg;
            return View(Srecord);
         
        }
    }
    
}