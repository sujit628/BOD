﻿var formElem = document.getElementById("setUPForm");
var form=$('#setUPForm');




(function () {
   // var e = document.getElementById("setUPForm");
    FormValidation.formValidation(formElem, {
        fields: {
            Designation: {
                validators: {
                    notEmpty: {
                        message: "Please enter Designation"
                    }
                }
            }
        },
        plugins: {
            trigger: new FormValidation.plugins.Trigger(),
            bootstrap5: new FormValidation.plugins.Bootstrap5({
                eleValidClass: "is-valid",
                rowSelector: function (formElem, t) {
                    return ".mb-3";
                },
            }),
            submitButton: new FormValidation.plugins.SubmitButton(),
            autoFocus: new FormValidation.plugins.AutoFocus(),
        },
    }).on('core.form.valid', function () {

        SaveRecord();
    });
})();


function SaveRecord() {

    var _data = form.serialize();
    $.ajax({
        type: "POST",
        url: URLList.SaveRecord,
        data: _data,
        async: false,
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
               
                //location.reload();
                var oTable = $('#datatable-example').DataTable();
                oTable.destroy();
                BindGrid();

                if ($('#Id').val() == '') {
                    $("#setUPFormPopUp .close").click();
                } else {
                    $('#setUPFormPopUp').removeClass('show');
                }
                $('.form-control').val('');
                
            }
            else {
               
            }
        },
        error: function (data) {
          

        }
    });

}


function retrive(id) {


    $('#setUPFormPopUp').addClass('show');
    $('.btn-close').click(function () {

        $('#setUPFormPopUp').removeClass('show');
        $('.form-control').val('');
    });

    var _data = JSON.stringify({
        global: {
            TransactionType: globalData.TransactionType,
            Param: globalData.Param,
            paramValue: parseInt(id),
            StoreProcedure: globalData.StoreProcedure
        }
    });

    $.ajax({
        type: "POST",
        url: URLList.GetEntityMasterById,
        contentType: "application/json; charset=utf-8",
        data: _data,
        dataType: "json",
        success: function (data) {
            //data = JSON.parse(data);
            $('#Id').val(data["DM_Id"]);
            $('#Designation').val(data["DM_Designation"]);
            $('#Description').val(data["DM_Description"]);

        },
        error: function (data) {
            alert("Process Not Sucess");
        }
    });
    return false;

}



