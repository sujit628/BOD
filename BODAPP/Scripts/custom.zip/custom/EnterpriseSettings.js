﻿var Id;
var M = "";

var formElem = document.getElementById("formAccountSettings");

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
           results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function retriveEnterprise(mode) {
    if (Id > 0) {

        var _data = JSON.stringify({
            global: {
                TransactionType: "Select",
                Param: "ENR_Id",
                paramValue: Id,
                StoreProcedure: "EnterpriseRegistration_USP"
            }
        });
    }
    else {
        var _data = JSON.stringify({
            global: {
                TransactionType: "Select",
                Param: "ENR_Id",

                StoreProcedure: "EnterpriseRegistration_USP"
            }
        });
    }
    $.ajax({
        type: "POST",
        url: "/ScriptJson/GetGlobalMaster",
        contentType: "application/json; charset=utf-8",
        data: _data,
        dataType: "json",
        success: function (data) {

            $('#hdnId').val(data["ENR_Id"]);
            if (mode == 'contact') {
                $('#txtContactName').val(data["ENR_PrimaryContactName"]);
                $('#txtContactEmail').val(data["ENR_PrimaryContactEmail"]);
                $('#SecondaryContactName').val(data["ENR_SecondaryContactName"]);
                $('#SecondaryContactEmail').val(data["ENR_SecondaryContactEmail"]);
                $('#PrimaryContactNumber').val(data["ENR_PrimaryContactNo"]);
                $('#SecondaryContactNumber').val(data["ENR_SecondaryContactNo"]);
                if (data["ENR_Logo"] == "NO") {

                    $('#dvImageWorkSpace').css('display', 'none');
                    var avatar = ' <div class="avatar avatar-xl"><span class="avatar-initial bg-label-' + ["success", "danger", "warning", "info", "primary", "secondary"][Math.floor(6 * Math.random())] + '">' + data["ENR_PreFix"] + '</span></div>';
                    $('#dvAvatar').append(avatar);
                }
                else {
                    $('#dvAvatar').css('display', 'none');
                    $('#hdnWorkSpceUpload').val(data["ENR_Logo"]);
                    $('#prfpicIMGWorkSpace').attr('src', data["ENR_Logo"]);
                }
            }
            else if (mode == 'company') {
                $('#txtCompanyName').val(data["ENR_CompanyName"]);
                $('#txtRegNum').val(data["ENR_RegNumber"]);
                $('#ddlSector').val(data["ENR_SectorId"]).change();
                //$('#ddlBusinessType').val(data["ENR_EnterpriseTypeId"]);
                $("#ddlBusinessType").val(data["ENR_EnterpriseTypeId"]).change();
                $('#ddlProvince').val(data["ENR_ProvinceId"]).change();
                $('#txtBusinessAddress').val(data["ENR_BusinessAddress"]);
                $('#txtPostalCode').val(data["ENR_PostalCode"]);
                $('#txtAddress2').val(data["ENR_Address2"]);
                $('#txtCity').val(data["ENR_City"]);
                $('#txtSuburb').val(data["ENR_Subarb"]);
                //$('#prfpicIMG').attr('src', data["ENR_CompanyLogo"]);
                
                $('#txtBusinessDesc').val(data["ENR_BussinessDescripton"]);
                if (data["ENR_CompanyLogo"] == "NO") {

                    $('#prfpicIMG').attr('src', '/Content/assets/img/avatars/default_companyphoto.png');
                }
                else {
                  
                    $('#prfpicIMG').attr('src', data["ENR_CompanyLogo"]);
                }
            }
            else if (mode == 'legal_entity') {
                $('#ddlLegalEntity').val(data["ENR_LegalEntityTypeId"]).change();
                $('#txtTaxNumber').val(data["ENR_TaxNumber"]);
                $('#txtVatNumber').val(data["ENR_VatNumber"]);
                $('#txtIncorporationDate').val(data["ENR_IncorporationDate"]);
                $('#txtRegNum2').val(data["ENR_RegNum2"]);
            }
            else if (mode == 'financial') {
                $('#txtBillingContactNum').val(data["ENR_BillingContactNumber"]);
                $('#txtBillingAddress').val(data["ENR_BillingAddress"]);
            }

        },
        error: function (data) {
            alert("Process Not Sucess");
        }
    });
    return false;

}

function SaveRecords(Type) {
    Id = getParameterByName('Id');
    if ($('#hdnId').val() == "") {
        var id = Id;
    } else {
        var id = $('#hdnId').val();
    }
    var _data = JSON.stringify({
        entity: {
            ENR_Id: id,
            Mode: $('#hdnMode').val(),
            ENR_PrimaryContactName: $.trim($('#txtContactName').val()),
            ENR_PrimaryContactEmail: $('#txtContactEmail').val(),
            ENR_Password: $('#txtPassword').val(),
            ENR_SecondaryContactName: $('#SecondaryContactName').val(),
            ENR_SecondaryContactEmail: $('#SecondaryContactEmail').val(),
            ENR_PrimaryContactNo: $('#PrimaryContactNumber').val(),
            ENR_SecondaryContactNo: $('#SecondaryContactNumber').val(),

            ENR_CompanyName: $.trim($('#txtCompanyName').val()),
            ENR_RegNumber: $('#txtRegNum').val(),
            ENR_SectorId: $('#ddlSector').val(),
            ENR_EnterpriseTypeId: $('#ddlBusinessType').val(),
            ENR_ProvinceId: $('#ddlProvince').val(),
            ENR_BusinessAddress: $('#txtBusinessAddress').val(),
            ENR_City: $('#txtCity').val(),
            ENR_Address2: $('#txtAddress2').val(),
            ENR_Subarb: $('#txtSuburb').val(),
            ENR_PostalCode: $('#txtPostalCode').val(),
            ENR_PhNumber: $('#txtPhNo').val(),
            ENR_Logo: $('#hdnWorkSpceUpload').val(),
            ENR_CompanyLogo: $('#hdnupload').val(),
            ENR_LegalEntityTypeId: $('#ddlLegalEntity').val(),
            ENR_TaxNumber: $('#txtTaxNumber').val(),
            ENR_VatNumber: $('#txtVatNumber').val(),
            ENR_IncorporationDate: $('#txtIncorporationDate').val(),
            ENR_RegNum2: $('#txtRegNum2').val(),

            ENR_BillingContactNumber: $('#txtBillingContactNum').val(),
            ENR_BillingAddress: $('#txtBillingAddress').val(),

        }
    }); $.ajax({
        type: "POST",
        url: '/ScriptJson/InsertUpdateEnterpriseRegn',
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
                //alert("Record saved successfully...");
                Id = data.Id;
                Swal.fire({
                    title: data.Message,
                    icon: "success",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });

                
                if (Type == 'N') {
                    fnNextRedirect();
                }

            }
            else {
                Swal.fire({
                    title: data.Message,
                    icon: "error",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
            }
        },
        error: function (data) {
            Swal.fire({
                title: 'Process Not Complete',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
        }
    });
}
function bytesToSize(bytes) {
    var sizes = ['B', 'K', 'M', 'G', 'T', 'P'];
    for (var i = 0; i < sizes.length; i++) {
        if (bytes <= 1024) {
            return bytes + ' ' + sizes[i];
        } else {
            bytes = parseInt(bytes / 1000);
        }
    }
    return bytes + ' P';
}
function ShowPreview(input) {

    var fileInput = $('#upload');
    var maxSize = fileInput.data('max-size');

    var size = bytesToSize(maxSize);

    if (fileInput.get(0).files.length) {
        var fileSize = fileInput.get(0).files[0].size; // in bytes

        var file = fileInput.get(0).files[0];
        var fileType = file["type"];
        var validImageTypes = ["image/png"];
        if ($.inArray(fileType, validImageTypes) < 0) {
            // invalid file type code goes here.
            Swal.fire({
                title: ' invalid file type',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
            return false;
        }


        //if (getOrientation(fileInput.get(0).files[0]) == false) {
        //    Swal.fire({
        //        title: 'invalid file Orientation',
        //        icon: "error",
        //        customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
        //        buttonsStyling: !1
        //    });
        //    return false;
        //}


        if (fileSize > maxSize) {

            Swal.fire({
                title: 'File size is more then ' + size + 'b',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
            return false;
        }

        else {
            if (input.files && input.files[0]) {
                var ImageDir = new FileReader();
                ImageDir.onload = function (e) {
                    $('#prfpicIMG').attr('src', e.target.result);
                }

                ImageDir.readAsDataURL(input.files[0]);

                UploadDoc('upload');
                pathFl = $('#upload').val().substring(12);
                pathStringFl = '/Upload/' + pathFl;
                var hdnImagePath = pathStringFl;
                $('#hdnupload').val(hdnImagePath);
               
            }
        }
    } else {

        Swal.fire({
            title: 'choose any one image, please',
            icon: "error",
            customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
            buttonsStyling: !1
        });
        return false;
    }

}
function ShowPreviewWorkSpace(input) {

    var fileInput = $('#uploadWorkSpce');
    var maxSize = fileInput.data('max-size');

    var size = bytesToSize(maxSize);

    if (fileInput.get(0).files.length) {
        var fileSize = fileInput.get(0).files[0].size; // in bytes

        var file = fileInput.get(0).files[0];
        var fileType = file["type"];
        var validImageTypes = ["image/png", "image/jpeg", "image/jpg"];
        if ($.inArray(fileType, validImageTypes) < 0) {
            // invalid file type code goes here.
            Swal.fire({
                title: ' invalid file type',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
            return false;
        }


        if (getOrientation(fileInput.get(0).files[0]) == false) {
            Swal.fire({
                title: 'invalid file Orientation',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
            return false;
        }


        if (fileSize > maxSize) {

            Swal.fire({
                title: 'File size is more then ' + size + 'b',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
            return false;
        }

        else {
            if (input.files && input.files[0]) {
                var ImageDir = new FileReader();
                ImageDir.onload = function (e) {
                    $('#prfpicIMGWorkSpace').attr('src', e.target.result);
                }

                ImageDir.readAsDataURL(input.files[0]);

                UploadDoc('uploadWorkSpce');
                pathFl = $('#uploadWorkSpce').val().substring(12);
                pathStringFl = '/Upload/' + pathFl;
                var hdnImagePath = pathStringFl;
                $('#hdnWorkSpceUpload').val(hdnImagePath);
            }
        }
    } else {

        Swal.fire({
            title: 'choose any one image, please',
            icon: "error",
            customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
            buttonsStyling: !1
        });
        return false;
    }

}

//For upload file into folder
function UploadDoc(upload) {
    var formData = new FormData();
    var totalFiles = document.getElementById(upload).files.length;
    for (var i = 0; i < totalFiles; i++) {
        var file = document.getElementById(upload).files[i];
        formData.append(upload, file);
    }
    $.ajax({
        type: "POST",
        url: '/ScriptJson/Upload',
        data: formData,
        dataType: 'json',
        contentType: false,
        processData: false,
        success: function (response) {
            M = getParameterByName('M');
            if (M != 'A') {
                $('#dvAvatar').css('display', 'none');
                $('#dvImage').css('display', 'block');
                UpdatePhoto();
            }

        }
    });
}

function UpdatePhoto() {
    Id = getParameterByName('Id');
    if ($('#hdnId').val() == "") {
        var id = Id;
    } else {
        var id = $('#hdnId').val();
    }
    var _data = JSON.stringify({
        entr: {
            ENR_Id: id,
            ENR_CompanyLogo: $('#hdnupload').val(),
                ENR_Logo: $('#hdnWorkSpceUpload').val(),
        }
    });
    $.ajax({
        type: "POST",
        url: "/ScriptJson/EnterprisePhotoUpdate",
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            $('#imgMainLayout').attr('src', $('#hdnupload').val());
            if (data != null && data != undefined && data.IsSuccess == true) {
                Swal.fire({
                    title: data.Message,
                    icon: "success",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });

            }

        },
        error: function (data) {
            Swal.fire({
                title: 'Process Not Complete',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
        }
    });

}

$(document).ready(function () {

    $('.alphabets').on('input', function () {
       
        let inputValue = $(this).val();

        let alphabeticValue = inputValue.replace(/[^a-zA-Z\s]/g, '');

        $(this).val(alphabeticValue);
    });
    DropdownBinder.DDLData = {
        tableName: "SectorSetUp_SM",
        Text: 'SM_SectorName',
        Value: 'SM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlSector");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "EnterpriseTypeSetUp_ETM",
        Text: 'ETM_EnterpriseType',
        Value: 'ETM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlBusinessType");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "ProvinceSetUp_PM",
        Text: 'PM_Province',
        Value: 'PM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlProvince");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "LegalEntitySetUp_LEM",
        Text: 'LEM_LegalEntity',
        Value: 'LEM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlLegalEntity");
    DropdownBinder.Execute();

    var mode = $('#hdnMode').val();

    Id = getParameterByName('Id');

    M = getParameterByName('M');
    if (M != 'A') {
        retriveEnterprise(mode);
    }
    else if (M == 'A' && Id > 0) {
        retriveEnterprise(mode);
    }
    else {
        $('#prfpicIMG').attr('src', '/Content/assets/img/avatars/default_photo.png');
    }

});
$(function () {
    var e = $(".ddlSector");
    var f = $(".ddlBusinessType");
    var g = $(".ddlProvince");
    var h = $(".ddlLegalEntity");
    e.length &&
        e.each(function () {
            var e = $(this);
            e.wrap('<div class="position-relative"></div>'), e.select2({ placeholder: "Select A Sector", dropdownParent: e.parent() });
        });

    f.length &&
       f.each(function () {
           var f = $(this);
           f.wrap('<div class="position-relative"></div>'), f.select2({ placeholder: "Select A Type", dropdownParent: f.parent() });
       });

    g.length &&
         g.each(function () {
             var g = $(this);
             g.wrap('<div class="position-relative"></div>'), g.select2({ placeholder: "Select A Province", dropdownParent: g.parent() });
         });
    h.length &&
        h.each(function () {
            var h = $(this);
            h.wrap('<div class="position-relative"></div>'), h.select2({ placeholder: "Select A LegalEntity", dropdownParent: h.parent() });
        });


    FormValidation.formValidation(formElem, {
        fields: {
            txtCompanyName: {
                validators: {
                    notEmpty: {
                        message: "Please enter enterprise name"
                    }
                }
            },
            txtRegNum: {
                validators: {
                    notEmpty: {
                        message: "Please enter registration number"
                    }
                }
            },
            ddlSector: {
                validators: {
                    notEmpty: {
                        message: "Please Select sector"
                    }
                }
            },
            ddlBusinessType: {
                validators: {
                    notEmpty: {
                        message: "Please Select business type"
                    }
                }
            },
            ddlProvince: {
                validators: {
                    notEmpty: {
                        message: "Please Select Province"
                    }
                }
            },
            txtContactName: {
                validators: {
                    notEmpty: {
                        message: "Please enter contact name"
                    }
                }
            },
            txtContactEmail: {
                validators: {
                    notEmpty: {
                        message: "Please enter email address"
                    },
                    emailAddress: {
                        message: "The value is not a valid email address"
                    }
                }
            },
            PrimaryContactNumber: {
                validators: {
                    notEmpty: {
                        message: "Please enter primary contact name"
                    }
                }
            },
            SecondaryContactEmail: {
                validators: {

                    emailAddress: {
                        message: "The value is not a valid email address"
                    }
                }
            }
        },
        plugins: {
            trigger: new FormValidation.plugins.Trigger(),
            bootstrap5: new FormValidation.plugins.Bootstrap5({
                eleValidClass: "is-valid",
                rowSelector: function (formElem, t) {
                    return ".mb-3";
                },
            }),
            submitButton: new FormValidation.plugins.SubmitButton(),
            autoFocus: new FormValidation.plugins.AutoFocus(),
        },
    }).on('core.form.valid', function () {

        SaveRecords('N');
    });

});


//Get Data From URL   
function fnCancelConfirm() {
    Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: !0,
        confirmButtonText: "Yes, Cancel it!",
        cancelButtonText: "Discard",
        customClass: { confirmButton: "btn btn-primary me-3 waves-effect waves-light", cancelButton: "btn btn-label-secondary waves-effect waves-light" },
        buttonsStyling: !1,
    }).then(function (t) {
        t.value && Swal.fire({
            icon: "danger",
            title: "Cancel!",
            text: "Your data has been cleared.",
            customClass: { confirmButton: "btn btn-danger waves-effect waves-light" }
        }).then(function () {
            $('#formAccountSettings').trigger("reset");
            //window.location.href = "/Home/ViewAllEnterpriseUserForAdmin";
        });

    });
}
function fnCancelRedirect() {
    Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: !0,
        confirmButtonText: "Yes, Cancel it!",
        cancelButtonText: "Discard",
        customClass: { confirmButton: "btn btn-primary me-3 waves-effect waves-light", cancelButton: "btn btn-label-secondary waves-effect waves-light" },
        buttonsStyling: !1,
    }).then(function (t) {
        t.value && Swal.fire({
            icon: "danger",
            title: "Cancel!",
            text: "Your data has been cleared.",
            customClass: { confirmButton: "btn btn-danger waves-effect waves-light" }
        }).then(function () {
            //$('#formAccountSettings').trigger("reset");
            window.location.href = "/Enterprise/EnterpriseLists";
        });

    });
}

function fnNextRedirect() {
    Swal.fire({
        title: "Your Save Changes Successfully!",
        icon: "success",
        customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
        //confirmButtonText:"Next",
        buttonsStyling: !1
    }).then(function () {
        var mode = $('#hdnMode').val();
                    if (Id > 0 && M == "A") {
                        if (mode == 'contact') {

                            window.location = "/Account/EnterpriseSettings_legalentity?Id=" + Id + '&M=A';
                        }
                        if (mode == 'company') {
                            window.location = "/Account/EnterpriseSettings_contact?Id=" + Id + '&M=A';

                        }
                        if (mode == 'legal_entity') {
                            window.location = "/Account/EnterpriseSettings_financial?Id=" + Id + '&M=A';
                        }
                        if (mode == 'financial') {
                            window.location = "/Enterprise/EnterpriseLists";
                        }
                    }
                    if (Id > 0 && M == "E") {
                        if (mode == 'contact') {

                            window.location = "/Account/EnterpriseSettings_legalentity?Id=" + Id + '&M=E';
                        }
                        if (mode == 'company') {
                            window.location = "/Account/EnterpriseSettings_contact?Id=" + Id + '&M=E';

                        }
                        if (mode == 'legal_entity') {
                            window.location = "/Account/EnterpriseSettings_financial?Id=" + Id + '&M=E';
                        }
                        if (mode == 'financial') {
                            window.location = "/Enterprise/EnterpriseLists";
                        }
                    }
                    else if (Id <= 0 && M == "A") {
                        if (mode == 'contact') {
                            window.location = "/Account/EnterpriseSettings_legalentity?Id=0&M=A";
                        }
                        if (mode == 'company') {
                            window.location = "/Account/EnterpriseSettings_contact?Id=0&M=A";
                        }
                        if (mode == 'legal_entity') {
                            window.location = "/Account/EnterpriseSettings_financial?Id=0&M=A";
                        }
                        if (mode == 'financial') {
                            window.location = "/Enterprise/EnterpriseLists";
                        }

                    }
                    else if (Id <= 0 && M != "A" && M != 'E') {
                        if (mode == 'contact') {
                            window.location = "/Account/EnterpriseSettings_legalentity";
                        }
                        if (mode == 'company') {
                            window.location = "/Account/EnterpriseSettings_contact";
                        }
                        if (mode == 'legal_entity') {
                            window.location = "/Account/EnterpriseSettings_financial";
                        }
                        if (mode == 'financial') {
                            window.location = "/Enterprise/EnterpriseLists";
                        }
                    }
    });
   
    
}
$("#btnCancel").on("click", function () {
    fnCancelConfirm();
});

$("#btnCancelRedirect").on("click", function () {
    fnCancelRedirect();
});


$("#btnResetUpload").on("click", function () {

    $('#prfpicIMG').attr('src', '/Content/assets/img/avatars/default_companyphoto.png');
});
$("#btnResetWorkSpceUpload").on("click", function () {

    $('#prfpicIMGWorkSpace').attr('src', '/Content/assets/img/avatars/default_photo.png');
});