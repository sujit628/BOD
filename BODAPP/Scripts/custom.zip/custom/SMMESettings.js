﻿var Id;
var M = "";
var formElem = document.getElementById("formAccountSettings");
$(function () {
    var e = $(".ddlSector");
    var f = $(".ddlBusinessType");
    var g = $(".ddlProvince");
    var h = $(".ddlLegalEntity");
    e.length &&
        e.each(function () {
            var e = $(this);
            e.wrap('<div class="position-relative"></div>'), e.select2({ placeholder: "Select A Sector", dropdownParent: e.parent() });
        });

    f.length &&
       f.each(function () {
           var f = $(this);
           f.wrap('<div class="position-relative"></div>'), f.select2({ placeholder: "Select A Type", dropdownParent: f.parent() });
       });

    g.length &&
         g.each(function () {
             var g = $(this);
             g.wrap('<div class="position-relative"></div>'), g.select2({ placeholder: "Select A Province", dropdownParent: g.parent() });
         });
    h.length &&
        h.each(function () {
            var h = $(this);
            h.wrap('<div class="position-relative"></div>'), h.select2({ placeholder: "Select A LegalEntity", dropdownParent: h.parent() });
        });
    FormValidation.formValidation(formElem, {
        fields: {
            txtCompanyName: {
                validators: {
                    notEmpty: {
                        message: "Please enter smme name"
                    }
                }
            },
            txtRegNum: {
                validators: {
                    notEmpty: {
                        message: "Please enter registration number"
                    }
                }
            },
            ddlSector: {
                validators: {
                    notEmpty: {
                        message: "Please Select sector"
                    }
                }
            },
            ddlBusinessType: {
                validators: {
                    notEmpty: {
                        message: "Please Select business type"
                    }
                }
            },
            ddlProvince: {
                validators: {
                    notEmpty: {
                        message: "Please Select Province"
                    }
                }
            },
            txtContactName: {
                validators: {
                    notEmpty: {
                        message: "Please enter contact name"
                    }
                }
            },
            txtContactEmail: {
                validators: {
                    notEmpty: {
                        message: "Please enter email address"
                    },
                    emailAddress: {
                        message: "The value is not a valid email address"
                    }
                }
            },
            PrimaryContactNumber: {
                validators: {
                    notEmpty: {
                        message: "Please enter primary contact name"
                    }
                }
            },
            SecondaryContactEmail: {
                validators: {

                    emailAddress: {
                        message: "The value is not a valid email address"
                    }
                }
            }

        },
        plugins: {
            trigger: new FormValidation.plugins.Trigger(),
            bootstrap5: new FormValidation.plugins.Bootstrap5({
                eleValidClass: "is-valid",
                rowSelector: function (formElem, t) {
                    return ".mb-3";
                },
            }),
            submitButton: new FormValidation.plugins.SubmitButton(),
            autoFocus: new FormValidation.plugins.AutoFocus(),
        },
    }).on('core.form.valid', function () {

        SaveRecords('N');
    });
}),


$(document).ready(function () {
    $('.alphabets').on('input', function () {

        let inputValue = $(this).val();

        let alphabeticValue = inputValue.replace(/[^a-zA-Z\s]/g, '');

        $(this).val(alphabeticValue);
    });
    DropdownBinder.DDLData = {
        tableName: "SectorSetUp_SM",
        Text: 'SM_SectorName',
        Value: 'SM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlSector");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "EnterpriseTypeSetUp_ETM",
        Text: 'ETM_EnterpriseType',
        Value: 'ETM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlBusinessType");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "ProvinceSetUp_PM",
        Text: 'PM_Province',
        Value: 'PM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlProvince");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "LegalEntitySetUp_LEM",
        Text: 'LEM_LegalEntity',
        Value: 'LEM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlLegalEntity");
    DropdownBinder.Execute();

    var mode = $('#hdnMode').val();

    Id = getParameterByName('Id');

    M = getParameterByName('M');
    if (M != 'A') {
        retrive(mode);
    }
    else if (M == 'A' && Id > 0) {
        retrive(mode);
    }
    else {
        $('#prfpicIMG').attr('src', '/Content/assets/img/avatars/default_photo.png');
    }

});
//Get Data From URL   
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
           results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
//function Next() {
//    var mode = $('#hdnMode').val();
//    if (Id > 0 && M == "A") {
//        if (mode == 'contact') {

//            window.location = "/Account/SMMESettings_legalentity?Id=" + Id + '&M=A';
//        }
//        if (mode == 'company') {
//            window.location = "/Account/SMMESettings_contact?Id=" + Id + '&M=A';

//        }
//        if (mode == 'legal_entity') {
//            window.location = "/Account/SMMESettings_financial?Id=" + Id + '&M=A';
//        }
//    }
//    if (Id > 0 && M == "E") {
//        if (mode == 'contact') {

//            window.location = "/Account/SMMESettings_legalentity?Id=" + Id + '&M=E';
//        }
//        if (mode == 'company') {
//            window.location = "/Account/SMMESettings_contact?Id=" + Id + '&M=E';

//        }
//        if (mode == 'legal_entity') {
//            window.location = "/Account/SMMESettings_financial?Id=" + Id + '&M=E';
//        }
//    }
//    else if (Id <= 0 && M == "A") {
//        if (mode == 'contact') {
//            window.location = "/Account/SMMESettings_legalentity?Id=0&M=A";
//        }
//        if (mode == 'company') {
//            window.location = "/Account/SMMESettings_contact?Id=0&M=A";
//        }
//        if (mode == 'legal_entity') {
//            window.location = "/Account/SMMESettings_financial?Id=0&M=A";
//        }

//    }
//    else if (Id <= 0 && M != "A" && M != 'E') {
//        if (mode == 'contact') {
//            window.location = "/Account/SMMESettings_legalentity";
//        }
//        if (mode == 'company') {
//            window.location = "/Account/SMMESettings_contact";
//        }
//        if (mode == 'legal_entity') {
//            window.location = "/Account/SMMESettings_financial";
//        }
//    }
//}
function retrive(mode) {
    if (Id > 0) {

        var _data = JSON.stringify({
            global: {
                TransactionType: "Select",
                Param: "SMME_Id",
                paramValue: Id,
                StoreProcedure: "SMMERegistration_USP"
            }
        });
    }
    else {
        var _data = JSON.stringify({
            global: {
                TransactionType: "Select",
                Param: "SMME_Id",

                StoreProcedure: "SMMERegistration_USP"
            }
        });
    }
    $.ajax({
        type: "POST",
        url: "/ScriptJson/GetGlobalMaster",
        contentType: "application/json; charset=utf-8",
        data: _data,
        dataType: "json",
        success: function (data) {

            $('#hdnId').val(data["SMME_Id"]);
            if (mode == 'contact') {
                $('#txtContactName').val(data["SMME_PrimaryContactName"]);
                $('#txtContactEmail').val(data["SMME_PrimaryContactEmail"]);
                $('#SecondaryContactName').val(data["SMME_SecondaryContactName"]);
                $('#SecondaryContactEmail').val(data["SMME_SecondaryContactEmail"]);
                $('#PrimaryContactNumber').val(data["SMME_PrimaryContactNo"]);
                $('#SecondaryContactNumber').val(data["SMME_SecondaryContactNo"]);
            }
            else if (mode == 'company') {
                $('#txtCompanyName').val(data["SMME_CompanyName"]);
                $('#txtRegNum').val(data["SMME_RegNumber"]);
                $('#ddlSector').val(data["SMME_SectorId"]).change();
              
                $("#ddlBusinessType").val(data["SMME_SMMETypeId"]).change();
                $('#ddlProvince').val(data["SMME_ProvinceId"]).change();
                $('#txtBusinessAddress').val(data["SMME_BusinessAddress"]);
                $('#txtPostalCode').val(data["SMME_PostalCode"]);
                $('#txtAddress2').val(data["SMME_Address2"]);
                $('#txtCity').val(data["SMME_City"]);
                $('#txtSuburb').val(data["SMME_Subarb"]);

                if (data["SMME_Logo"] == "NO") {

                    $('#dvImage').css('display', 'none');
                    var avatar = ' <div class="avatar avatar-xl"><span class="avatar-initial bg-label-' + ["success", "danger", "warning", "info", "primary", "secondary"][Math.floor(6 * Math.random())] + '">' + data["SMME_PreFix"] + '</span></div>';
                    $('#dvAvatar').append(avatar);
                }
                else {
                    $('#dvAvatar').css('display', 'none');
                    $('#hdnupload').val(data["SMME_Logo"]);
                    $('#prfpicIMG').attr('src', data["SMME_Logo"]);
                }
            }
            else if (mode == 'legal_entity') {
                $('#ddlLegalEntity').val(data["SMME_LegalEntityTypeId"]).change();
                $('#txtTaxNumber').val(data["SMME_TaxNumber"]);
                $('#txtVatNumber').val(data["SMME_VatNumber"]);
                $('#txtIncorporationDate').val(data["SMME_IncorporationDate"]);
                $('#txtRegNum2').val(data["SMME_RegNum2"]);
            }
            else if (mode == 'financial') {
                $('#txtBillingContactNum').val(data["SMME_BillingContactNumber"]);
                $('#txtBillingAddress').val(data["SMME_BillingAddress"]);
            }

        },
        error: function (data) {
            alert("Process Not Sucess");
        }
    });
    return false;

}
//$("#btnUpdateNext").click(function () {
//    SaveRecords('N');

//});
//$("#btnUpdate").click(function () {
//    SaveRecords('U');
//});
function SaveRecords(Type) {
    Id = getParameterByName('Id');
    if ($('#hdnId').val() == "") {
        var id = Id;
    } else {
        var id = $('#hdnId').val();
    }
    var _data = JSON.stringify({
        entity: {
            SMME_Id: id,
            Mode: $('#hdnMode').val(),
            SMME_PrimaryContactName: $.trim($('#txtContactName').val()),
            SMME_PrimaryContactEmail: $('#txtContactEmail').val(),
            SMME_Password: $('#txtPassword').val(),
            SMME_SecondaryContactName: $('#SecondaryContactName').val(),
            SMME_SecondaryContactEmail: $('#SecondaryContactEmail').val(),
            SMME_PrimaryContactNo: $('#PrimaryContactNumber').val(),
            SMME_SecondaryContactNo: $('#SecondaryContactNumber').val(),

            SMME_CompanyName: $.trim($('#txtCompanyName').val()),
            SMME_RegNumber: $('#txtRegNum').val(),
            SMME_SectorId: $('#ddlSector').val(),
            SMME_SMMETypeId: $('#ddlBusinessType').val(),
            SMME_ProvinceId: $('#ddlProvince').val(),
            SMME_BusinessAddress: $('#txtBusinessAddress').val(),
            SMME_City: $('#txtCity').val(),
            SMME_Address2: $('#txtAddress2').val(),
            SMME_Subarb: $('#txtSuburb').val(),
            SMME_PostalCode: $('#txtPostalCode').val(),
            SMME_PhNumber: $('#txtPhNo').val(),
            SMME_Logo: $('#hdnupload').val(),

            SMME_LegalEntityTypeId: $('#ddlLegalEntity').val(),
            SMME_TaxNumber: $('#txtTaxNumber').val(),
            SMME_VatNumber: $('#txtVatNumber').val(),
            SMME_IncorporationDate: $('#txtIncorporationDate').val(),
            SMME_RegNum2: $('#txtRegNum2').val(),

            SMME_BillingContactNumber: $('#txtBillingContactNum').val(),
            SMME_BillingAddress: $('#txtBillingAddress').val(),

        }
    }); $.ajax({
        type: "POST",
        url: '/ScriptJson/InsertUpdateSMMERegistration',
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
              
                Id = data.Id;
                Swal.fire({
                    title: data.Message,
                    icon: "success",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });

              
                if (Type == 'N') {
                    fnNextRedirect()

                }

            }
            else {
                Swal.fire({
                    title: data.Message,
                    icon: "error",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
            }
        },
        error: function (data) {
            Swal.fire({
                title: 'Process Not Complete',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
        }
    });
    }
function bytesToSize(bytes) {
    var sizes = ['B', 'K', 'M', 'G', 'T', 'P'];
    for (var i = 0; i < sizes.length; i++) {
        if (bytes <= 1024) {
            return bytes + ' ' + sizes[i];
        } else {
            bytes = parseInt(bytes / 1000);
        }
    }
    return bytes + ' P';
}
function ShowPreview(input) {

    var fileInput = $('#upload');
    var maxSize = fileInput.data('max-size');

    var size = bytesToSize(maxSize);

    if (fileInput.get(0).files.length) {
        var fileSize = fileInput.get(0).files[0].size; // in bytes


        if (fileSize > maxSize) {

            Swal.fire({
                title: 'File size is more then ' + size + 'b',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
            return false;
        }

        else {
            if (input.files && input.files[0]) {
                var ImageDir = new FileReader();
                ImageDir.onload = function (e) {
                    $('#prfpicIMG').attr('src', e.target.result);
                }

                ImageDir.readAsDataURL(input.files[0]);

                UploadDoc('upload');
                pathFl = $('#upload').val().substring(12);
                pathStringFl = '/Upload/' + pathFl;
                var hdnImagePath = pathStringFl;
                $('#hdnupload').val(hdnImagePath);
            }
        }
    } else {

        Swal.fire({
            title: 'choose any one image, please',
            icon: "error",
            customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
            buttonsStyling: !1
        });
        return false;
    }

}

//For upload file into folder
function UploadDoc(upload) {
    var formData = new FormData();
    var totalFiles = document.getElementById(upload).files.length;
    for (var i = 0; i < totalFiles; i++) {
        var file = document.getElementById(upload).files[i];
        formData.append(upload, file);
    }
    $.ajax({
        type: "POST",
        url: '/ScriptJson/Upload',
        data: formData,
        dataType: 'json',
        contentType: false,
        processData: false,
        success: function (response) {
            M = getParameterByName('M');
            if (M != 'A') {
                $('#dvAvatar').css('display', 'none');
                $('#dvImage').css('display', 'block');
                UpdatePhoto();
            }

        }
    });
}

function UpdatePhoto() {
    Id = getParameterByName('Id');
    if ($('#hdnId').val() == "") {
        var id = Id;
    } else {
        var id = $('#hdnId').val();
    }
    var _data = JSON.stringify({
        entr: {
            SMME_Id: id,
            SMME_Logo: $('#hdnupload').val(),
        }
    });
    $.ajax({
        type: "POST",
        url: "/ScriptJson/SMMEPhotoUpdate",
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
                Swal.fire({
                    title: data.Message,
                    icon: "success",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
               
            }

        },
        error: function (data) {
            Swal.fire({
                title: 'Process Not Complete',
                icon: "error",
                customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                buttonsStyling: !1
            });
        }
    });

}


function fnCancelConfirm() {
    Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: !0,
        confirmButtonText: "Yes, Cancel it!",
        cancelButtonText: "Discard",
        customClass: { confirmButton: "btn btn-primary me-3 waves-effect waves-light", cancelButton: "btn btn-label-secondary waves-effect waves-light" },
        buttonsStyling: !1,
    }).then(function (t) {
        t.value && Swal.fire({
            icon: "danger",
            title: "Cancel!",
            text: "Your data has been cleared.",
            customClass: { confirmButton: "btn btn-danger waves-effect waves-light" }
        }).then(function () {
            $('#formAccountSettings').trigger("reset");
            //window.location.href = "/Home/ViewAllEnterpriseUserForAdmin";
        });

    });
}
function fnCancelRedirect() {

   
    Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: !0,
        confirmButtonText: "Yes, Cancel it!",
        cancelButtonText:"Discard",
        customClass: { confirmButton: "btn btn-primary me-3 waves-effect waves-light", cancelButton: "btn btn-label-secondary waves-effect waves-light" },
        buttonsStyling: !1,
    }).then(function (t) {
        t.value && Swal.fire({
            icon: "danger",
            title: "Cancel!",
            text: "Your data has been cleared.",
            customClass: { confirmButton: "btn btn-danger waves-effect waves-light" }
        }).then(function () {
            //$('#formAccountSettings').trigger("reset");
            if (parseInt($('#hdnEnterId').val()) > 0)
            {
                window.location.href = "/Enterprise/ViewAllSMMEForEnterprise";
            }
            else{ window.location.href = "/SMME/SMMELists";
            }
            

        });

    });
}

function fnNextRedirect() {

    Swal.fire({
        title: "Your Save Changes Successfully!",
        icon: "success",
        customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
        //confirmButtonText: "Next",

        buttonsStyling: !1
    }).then(function () {
        var mode = $('#hdnMode').val();
            if (Id > 0 && M == "A") {
                if (mode == 'contact') {

                    window.location = "/Account/SMMESettings_legalentity?Id=" + Id + '&M=A';
                }
                if (mode == 'company') {
                    window.location = "/Account/SMMESettings_contact?Id=" + Id + '&M=A';

                }
                if (mode == 'legal_entity') {
                    window.location = "/Account/SMMESettings_financial?Id=" + Id + '&M=A';
                }
                if (mode == 'financial') {
                    if (parseInt($('#hdnEnterId').val()) > 0) {
                        window.location.href = "/Enterprise/ViewAllSMMEForEnterprise";
                    }
                    else {
                        window.location.href = "/SMME/SMMELists";
                    }

                }
            }
            if (Id > 0 && M == "E") {
                if (mode == 'contact') {

                    window.location = "/Account/SMMESettings_legalentity?Id=" + Id + '&M=E';
                }
                if (mode == 'company') {
                    window.location = "/Account/SMMESettings_contact?Id=" + Id + '&M=E';

                }
                if (mode == 'legal_entity') {
                    window.location = "/Account/SMMESettings_financial?Id=" + Id + '&M=E';
                }
                if (mode == 'financial') {
                    if (parseInt($('#hdnEnterId').val()) > 0) {
                        window.location.href = "/Enterprise/ViewAllSMMEForEnterprise";
                    }
                    else {
                        window.location.href = "/SMME/SMMELists";
                    }

                }
            }
            else if (Id <= 0 && M == "A") {
                if (mode == 'contact') {
                    window.location = "/Account/SMMESettings_legalentity?Id=0&M=A";
                }
                if (mode == 'company') {
                    window.location = "/Account/SMMESettings_contact?Id=0&M=A";
                }
                if (mode == 'legal_entity') {
                    window.location = "/Account/SMMESettings_financial?Id=0&M=A";
                }
                if (mode == 'financial') {
                    if (parseInt($('#hdnEnterId').val()) > 0) {
                        window.location.href = "/Enterprise/ViewAllSMMEForEnterprise";
                    }
                    else {
                        window.location.href = "/SMME/SMMELists";
                    }

                }

            }
            else if (Id <= 0 && M != "A" && M != 'E') {
                if (mode == 'contact') {
                    window.location = "/Account/SMMESettings_legalentity";
                }
                if (mode == 'company') {
                    window.location = "/Account/SMMESettings_contact";
                }
                if (mode == 'legal_entity') {
                    window.location = "/Account/SMMESettings_financial";
                }
                if (mode == 'financial') {
                    if (parseInt($('#hdnEnterId').val()) > 0) {
                        window.location.href = "/Enterprise/ViewAllSMMEForEnterprise";
                    }
                    else {
                        window.location.href = "/SMME/SMMELists";
                    }

                }
            }
       
        });
    
    }
$("#btnCancel").on("click", function () {
    fnCancelConfirm();
});

$("#btnCancelRedirect").on("click", function () {
    fnCancelRedirect();
});

$("#btnResetUpload").on("click", function () {
    
    $('#prfpicIMG').attr('src', '/Content/assets/img/avatars/default_photo.png');
});