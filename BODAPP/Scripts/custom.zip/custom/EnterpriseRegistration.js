﻿function SaveRecords() {

    var _data = JSON.stringify({
        entity: {
            ENR_Id: $('#hdnId').val(),
            ENR_PrimaryContactName: $.trim($('#txtContactName').val()),
            ENR_PrimaryContactEmail: $('#txtContactEmail').val(),
            ENR_Password: $('#txtPassword').val(),
            ENR_SecondaryContactName: $('#SecondaryContactName').val(),
            ENR_SecondaryContactEmail: $('#SecondaryContactEmail').val(),
            ENR_PrimaryContactNo: $('#PrimaryContactNumber').val(),
            ENR_SecondaryContactNo: $('#SecondaryContactNumber').val(),

            ENR_CompanyName: $.trim($('#txtCompanyName').val()),
            ENR_RegNumber: $('#txtRegNum').val(),
            ENR_SectorId: $('#ddlSector').val(),
            ENR_EnterpriseTypeId: $('#ddlBusinessType').val(),
            ENR_ProvinceId: $('#ddlProvince').val(),
            ENR_BusinessAddress: $('#txtBusinessAddress').val(),

            ENR_LegalEntityTypeId: $('#ddlLegalEntity').val(),
            ENR_TaxNumber: $('#txtTaxNumber').val(),
            ENR_VatNumber: $('#txtVatNumber').val(),
            ENR_IncorporationDate: $('#txtIncorporationDate').val(),
            ENR_RegNum2: $('#txtRegNum2').val(),
            
            ENR_BillingContactNumber: $('#txtBillingContactNum').val(),
            ENR_BillingAddress: $('#txtBillingAddress').val(),
            
        }
    }); $.ajax({
        type: "POST",
        url: '/ScriptJson/InsertUpdateEnterpriseRegn',
        data: _data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data != null && data != undefined && data.IsSuccess == true) {
                Swal.fire({
                    title:  data.Message,
                    icon: "success",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
                $(".form-control").val('')
                location.reload();
                window.location = "/Enterprise/EnterpriseDashboard";

            }
            else {
               
                Swal.fire({
                    title: data.Message,
                    icon: "error",
                    customClass: { confirmButton: "btn btn-primary waves-effect waves-light" },
                    buttonsStyling: !1
                });
            }
        },
        error: function (data) {
            alert("error", 'Process Not Complete');
        }
    });
}
$(document).ready(function () {

    $('.alphabets').on('input', function () {

        let inputValue = $(this).val();

        let alphabeticValue = inputValue.replace(/[^a-zA-Z\s]/g, '');

        $(this).val(alphabeticValue);
    });
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!

    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    var today = dd + '/' + mm + '/' + yyyy;
    txtApntDate = $("#txtApntDate").val();


    if (txtApntDate == "") {
        document.getElementById("txtApntDate").value = today;
    }

    DropdownBinder.DDLData = {
        tableName: "SectorSetUp_SM",
        Text: 'SM_SectorName',
        Value: 'SM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlSector");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "EnterpriseTypeSetUp_ETM",
        Text: 'ETM_EnterpriseType',
        Value: 'ETM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlBusinessType");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "ProvinceSetUp_PM",
        Text: 'PM_Province',
        Value: 'PM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlProvince");
    DropdownBinder.Execute();

    DropdownBinder.DDLData = {
        tableName: "LegalEntitySetUp_LEM",
        Text: 'LEM_LegalEntity',
        Value: 'LEM_Id'
    };
    DropdownBinder.DDLElem = $("#ddlLegalEntity");
    DropdownBinder.Execute();

});


